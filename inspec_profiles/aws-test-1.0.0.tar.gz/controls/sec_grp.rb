title 'Security groups shall not contain Internet ingress 0.0.0.0/0 rules for blacklisted ports'

control 'sgs-aws-1.40.01' do
  impact 1.0
  title 'Security groups shall not contain Internet ingress 0.0.0.0/0 rules for blacklisted ports - Ensure no security group allows unfiltered access from the Internet to administrative remote console services'
  desc 'Security groups provide stateful filtering of ingress/egress network traffic to AWS resources. Unrestricted access from the Internet to remote console services such as ssh (port 22) , 23 (Telnet) and RDP (port 3389) , common database ports e.g. 1433 (MSSQL Server) , 1434 (MSSQL Monitor) , 3306 (MySQL) , Oracle (1521) and 5432 (PostgreSQL) or any backend services used for monitoring, management or internal integration MUST be removed.'

  tag sgs_control_id: '1.40.01'
  tag sgs_control_hash: '8ae223887226fcbd01722703b9830017'

  aws_security_groups.group_names.each do |group_name|
    next if group_name == 'Red Hat Enterprise Linux -RHEL- 7 -HVM--7-7_HVM-AutogenByAWSMP-' || group_name == 'Red Hat Enterprise Linux -RHEL- 7 -HVM--7-7_HVM-AutogenByAWSMP-' || group_name == 'compliance-ibhobbhcyvkzszm'
    describe aws_security_group(group_name: group_name) do
      # Do not allow unrestricted IPv4 access.
      it { should_not allow_in(ipv4_range: '0.0.0.0/0') }

      # 1.40.01.01 - Firewall Rules for DB ports
      [5432, 3306, 4333, 1521, 27017, 1433, 1434].each do |db_port|
        it { should_not allow_in(port: db_port, ipv4_range: '0.0.0.0/0') }
      end

      # 1.40.01.02 - Firewall Rules for ADMIN ports
      [3389, 22, 5500, 5900, 135, 514].each do |admin_port|
        it { should_not allow_in(port: admin_port, ipv4_range: '0.0.0.0/0') }
      end

      # 1.40.01.03 - Firewall Rules for Infrastructure ports
      [53, 80, 110, 25, 67, 68, 161, 162].each do |infra_port|
        it { should_not allow_in(port: infra_port, ipv4_range: '0.0.0.0/0') }
      end

      # 1.40.01.04 - Firewall Rules for Fileshare ports
      [139, 445, 21, 69].each do |file_port|
        it { should_not allow_in(port: file_port, ipv4_range: '0.0.0.0/0') }
      end

      # 1.40.01.05 - Firewall Rules for telnet port
      it { should_not allow_in(port: 23, ipv4_range: '0.0.0.0/0') }
    end
  end
end
